import React from 'react'
import '../App.css';
import profile from "../Assets/PROFILE.jpg";
import Banner from "../Assets/banner.jpg";
import { useNavigate } from 'react-router-dom';
import { useState,useEffect } from 'react';
import axios from 'axios';

const Profile = () => {


  const navigate=useNavigate();
  const user=localStorage.getItem("user") || '{}'
  
      const [userdata,setUserdata]=useState<any>();
      useEffect(()=>{
        const getEmployeeData = async ()=>{
           await axios.get(`http://localhost:7000/employeedata/${user}`).then((response) => {
              
          setUserdata(response.data)
          
        });
      }
        
        getEmployeeData();
        
      
      },[])
      console.log(userdata)



      const camel =(mySentence:string)=> {
        const words=mySentence.split(" ");

      for (let i = 0; i < words.length; i++) {
         words[i] = words[i][0].toUpperCase() + words[i];
      }


     return words.join(" ")
    }


  return (
    <>
    {userdata?.map((user:any) => 
          <div className="user-profile">
      
          <div className="gradient" style={{backgroundImage:`url(${Banner})`}}></div>    
          <div className="profile-image">
              <img src={profile} alt=""/>
              <div className="profile-info">
                 <div className="profile-title" >{user.username.toUpperCase().split(" ")[0]}</div>
                 <div className="profile-desc">{user.designation.toUpperCase()}</div>
              </div>
          </div>
          
          <div className="user-info">
              <div className='user-info-1' >
                  <p>Name: { camel(user.username)}</p>
                  <p>Email: {user.email}</p>
                  <p>Gender: {camel(user.gender)}</p>
                           
              </div>

              <div className='user-info-2'>
                 
                  <p>Emp ID: {user.empid.toUpperCase()}</p>
                  <p>Desigation: {camel(user.designation)}</p>
                  <p>Date Of Joining: 2023-March </p>
                        
              </div>
          </div>
          <div className="submit-container">

<div className="Submit" >Edit</div>

<div className="Submit">Save</div>

</div>

    </div>)}
</>
  )

}

 

export default Profile;