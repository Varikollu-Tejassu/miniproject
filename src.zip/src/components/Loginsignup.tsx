import React, { useState } from 'react';
import axios from 'axios';
import email_icon from "../Assets/email-icon.png";
import pass_icon from "../Assets/pass-icon.png";
import user_icon from "../Assets/user-icon.png";
import jman_icon from "../Assets/jman-icon.png";
import { useNavigate } from 'react-router-dom';

 

import '../App.css';

function Loginsignup() {

  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState('');
  const [empid, setEmpid] = useState("")
  const [gender, setGender] = useState(" ")
  const [designation, setDesignation] = useState("")
  const [cpassword, setCpassword] = useState('')
  const navigate=useNavigate();


 

  const Login = () => {
    const Formempty=()=>{
        
        setEmail("");
        setPassword("");
        
    }

    if(email!==""){
        if(password.length>0 && password!==""){
            localStorage.setItem("user",JSON.stringify(email))
            axios.post("http://localhost:7000/login",{
                
                email:email,
                password:password}).then((response) => {
                console.log(response.data)})
                if(Response){
        
                    navigate("/dashboard");
                    Formempty();
                 }
        }       
        else{alert("Password should be greater than 6 characters!")
        Formempty();
    }
        
    }
    else{
        alert("Email should not be empty!")
        Formempty();
    }
    
     
        
   

  }

  const Register=()=>{
    

    const Formempty=()=>{
        setUsername("");
        setEmail("");
        setPassword("");
        setEmpid("");
        setCpassword("");
        setDesignation("");
        setAction("Login");
    }
    
    if(username!==""){
       if(email!==""){
            if(empid!==""){
                if(designation!==""){
                    if(password!=="" && password.length>=6){
                        if(password===cpassword){
                            localStorage.setItem("user",JSON.stringify(email))
                            axios.post("http://localhost:7000/register",{
                                    username:username,
                                    email:email,
                                    empid:empid,
                                    designation:designation,
                                    gender:gender,
                                    password:password


                                    }).then((response)=>{
                                        console.log(response.data);
                                    });

                                    Formempty();






                        }
                        else{
                            alert("Passwords are not matching!")
                        }
                    }
                    else{
                        alert("Password must be greater than 6 characters!")
                    }
                }
                else{
                    alert("Designation shoud not be empty!")
                }
            }
            else{
                alert("Employee Id shoud not be empty!")
            }
        }
        else{
            alert("Email should not be empty")
        }
      
    }
    else{
        alert("Username should not be empty ")
    }
    


  }

 

  const [action,setAction]=useState("Login")

 

  return (
<>
   <div className='container'  >

    {action==="Login"?null:<div className="header">

        <div className="text">

            Register Now!

        </div>

        <div className="underline"></div>

    </div>}
    <div className="logo">
        <img src={jman_icon} alt="" />
    </div>

    <div className="inputs">

        {action==="Login"?<div></div>:<div className="input">

            <img src={user_icon} alt=""/>

            <input type="text" placeholder='Name' value={username} onChange={(e)=>setUsername(e.target.value)} required/>

        </div>}

        

 

        <div className="input">

            <img src={email_icon} alt=""/>

            <input type="email"  placeholder='Email'  value={email} onChange={(e)=>setEmail(e.target.value)} required/>

        </div>
                {action==="Login"?null:<div className="input">

        <img src={user_icon} alt="" />

        <input type="text" placeholder='Employee Id' value={empid} onChange={(e)=>setEmpid(e.target.value)} required/>

        </div>}

        {action==="Login"?null:<div className="radio" >
        <input type="radio" value="Male" name="gender"  onChange={(e) => {setGender(e.currentTarget.value)}} />&nbsp; Male
        <input type="radio" value="Female" name="gender" onChange={(e) => {setGender(e.currentTarget.value)}}/> &nbsp;Female
        <input type="radio" value="Other" name="gender" onChange={(e) => {setGender(e.currentTarget.value)}} />&nbsp; Other
      </div>}

      {action==="Login"?null:<div className="input">

        <img src={user_icon} alt="" />

        <input type="text" placeholder='Designation' value={designation} onChange={(e)=>setDesignation(e.target.value)} required/>

        </div>}
 

        <div className="input">

            <img src={pass_icon} alt=""/>

            <input type="password" placeholder='Password' value={password} onChange={(e)=>setPassword(e.target.value)} required/>

        </div>

        {action==="Login"?<div className="input" >

           <button onClick={Login}>Login</button>

        </div>:null}

 

        {action==="Login"?<div className="checkbox">

              <input className="check-input" type="checkbox" value="" id="form1Example3" />

              <label className="check-label" htmlFor="form1Example3"> Remember password </label>

            </div>:null}

 

        {action==="Login"?null:<div className="input">

            <img src={pass_icon} alt=""/>

            <input type="password" placeholder='Confirm Password'  value={cpassword} onChange={(e)=>setCpassword(e.target.value)} required/>

        </div>}
    

        

 

    </div>

{action==="Sign Up"?null: <div className="forgot-password" >Forgot Password? <span onClick={()=>{alert("page not developed")}}>Click Here!</span>

 

<div className='register'>Don't have an account? <span onClick={()=>{setAction("Sign Up")}}>Create New!</span></div>

<br/>

<div><hr style={{width:"200px",marginRight:"150px"}}/></div>

</div>}

    <div className="submit-container">

    {action==="Login"?null:<div className={action==="Login"?"Submit gray" :"Submit"} onClick={Register}>Sign Up</div>}

    {action==="Login"?null:<div className={action==="Sign Up"?"Submit gray":"Submit"} onClick={()=>{setAction("Login")}}>Login</div>}

    </div>
    <div className="forgot-password">

                  {action ==="Login"?<p style={{fontSize:"15px",fontWeight:"700",marginTop:"-11vh"}}>or sign in with:</p>:<p style={{fontSize:"15px",fontWeight:"700"}}>or sign up with:</p>}
                  <div className='icons' >
                  <i className="fa-brands fa-facebook fa-2xl" style={{color: "#1877F2"}}></i> 
                  &nbsp;&nbsp; &nbsp;       
                  <i className="fa-brands fa-google fa-2xl" style={{color: "#DB4437"}}></i>
                  &nbsp;&nbsp; &nbsp;
                  <i className="fa-brands fa-linkedin fa-2xl" style={{color: "#0077b5"}}></i>
                  </div>
                    
                </div>
    
   </div>
   <div className="footer">&copy; Copyright 2023 All Rights Reserved
</div>
   </>

  );

}

 

export default Loginsignup;