import React ,{useEffect,useState}from 'react'
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

// type dtype={
//     username:string,
//     email:string,
//     gender:string,
//     designation:string,
//     password:string,
//     empid:string

// }
const Dashboard = () => {

    const navigate=useNavigate();
    const user=localStorage.getItem("user") || '{}'
    
        const [userdata,setUserdata]=useState<any>();
        useEffect(()=>{
          const getEmployeeData = async ()=>{
             await axios.get(`http://localhost:7000/employeedata/${user}`).then((response) => {
                
            setUserdata(response.data)
            
          });
        }
          
          getEmployeeData();
          
        
        },[])
        console.log(userdata)

 const logout=()=>{

    localStorage.clear();
    navigate("/")

 }

  return (
    <>
    
    <div className="menu">
    <ul>
        <li><Link style={{textDecoration:"none",color:"white"}} to="/dashboard">Dashboard</Link></li>
        <li>Timesheet</li>
        <li>Projects</li>
        <li>Leave</li>
        <li>Work From Home</li>
        <li>Approvals</li>
        <li>Survey</li>
        <li>Service Desk</li>
        <li>Forms</li>
        <li>Travel</li>
        <li>Expenses</li>
        <li>Settings</li>
        <li>Control Panel</li>
        <li>Resourcing</li>
        <li>Access Control </li>
        {userdata?.map((user:any) =>
        <div style={{display:"flex",flexDirection:"row",marginTop:"10%"}}>
        
         <li><Link to="/dashboard/profile" style={{textDecoration:"none",color:"white"}}>{user.username.toUpperCase()}</Link></li>
         
        <li style={{marginLeft:"5%",position:"absolute"}}><button onClick={logout}><i className="fa-solid fa-arrow-right-from-bracket" style={{color: "#0f1724"}}></i></button></li>
        </div>)}

    </ul>

</div>






</>

  )
}

export default Dashboard;