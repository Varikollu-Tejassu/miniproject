
import { BrowserRouter,Routes,Route } from 'react-router-dom';

import './App.css';
import Layout from './pages/Layout';
import Loginsignup from './components/Loginsignup';
import Dashboardcontent from './components/Dashboardcontent';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';








  
const App=():React.ReactElement=>{
    return (
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Loginsignup/>}/>
        <Route path='/dashboard' element={<Layout/>} >

        <Route path="/dashboard" element={<Dashboardcontent/>}/>
        <Route path="/dashboard" element={<Dashboard/>}/>
        <Route path="/dashboard/profile" element={<Profile/>}/>



        </Route>
        
      </Routes>
      </BrowserRouter>
    )
  }
  
  export default App






































































// const App=():React.ReactElement=> {
//   type Data={
//     userId:number,
//     id:number,
//     title:string,
//     completed:boolean
    
//   }

 

//   const [data, setData] = useState<Data[]>([]);
//   useEffect(() => {
//     bala();
//   }, []);
  
//   const bala=async() => {
//      const api= await axios.get("https://jsonplaceholder.typicode.com/todos");

//     setData(api.data);
    
//   }

//   type Inputs = { email: string,address:string}
//   const [inputs, setInputs] = useState<Inputs>({ email: "",address:""})
//  const onChangeInput=(e:any)=>{
//    setInputs({...inputs,[e.target.name]:[e.target.value]})
  
//    console.log(inputs)
//  }





//   return (
//     <div className="App">
//    {
//     data.map((item:Data)=>(
//       <ul>
//       <li>{item.id}</li>
//       <li>{item.userId}</li>
//       <li>{item.title}</li>
//       <li>{item.completed}</li>
//       </ul>
//     ))
//    }

//    <label>
//     Email
//     <input name="email"
//         onChange={onChangeInput}
//         value={inputs.email}
//     />
//      <input  name='address'
//         onChange={onChangeInput}
//         value={inputs.address}
//     />
   
// </label>

// <li>{inputs.email}</li>
// <li>{inputs.address}</li>
       
//     </div>
//   );
// }

// export default App;



